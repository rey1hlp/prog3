﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ResearchSoftPUCP
{
    /*
     * Colocar datos:
     * --------------------------------------
     * Código PUCP: 
     * Nombre Completo: 
     */
    public partial class GestionarGruposInvestigacion : System.Web.UI.Page
    {
        private byte[] foto;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["foto"] != null)
                foto = (byte[]) Session["foto"];
            //Cambiar el título a 'Datos del Grupo de Investigación' cuando haya ingresado via el botón 'Mostrar Datos'
            lblTitulo.Text = "Registrar Grupo de Investigación";
        }

        public void mostrarDatos()
        {
            lblTitulo.Text = "Datos del Grupo de Investigación";
            //Completar con la asignación
            //Por ejemplo:

            //dtpFechaFundacion.Value = grupoInvestigacion.FechaFundacion.ToString("yyyy-MM-dd");
            //string base64String = Convert.ToBase64String(grupoInvestigacion.Foto);
            //string imageUrl = "data:image/jpeg;base64," + base64String;
            //imgFotoGrupo.ImageUrl = imageUrl;

            //Desactivamos los controles para evitar su edicion
            txtNombre.Enabled = false;
            txtAcronimo.Enabled = false;
            ddlDepartamento.Enabled = false;
            btnGuardar.Enabled = false;
            btnSubirFotoGrupo.Visible = false;
            fileUploadFotoGrupo.Visible = false;
            rbTipoInvestigacion.Enabled = false;
            cbInfraestructura.Enabled = false;
            dtpFechaFundacion.Enabled = false;
            txtPresupuestoAnual.Enabled = false;
            txtDescripcion.Disabled = true;
            lbBuscarIntegrante.Visible = false;
            lbAgregarIntegrante.Visible = false;
            gvIntegrantes.Columns[4].Visible = false;
        }

        protected void btnSubirFotoGrupo_Click(object sender, EventArgs e)
        {
            //Verificar si se seleccionó un archivo
            if (fileUploadFotoGrupo.HasFile)
            {
                // Obtener la extensión del archivo
                string extension = System.IO.Path.GetExtension(fileUploadFotoGrupo.FileName);
                // Verificar si el archivo es una imagen
                if (extension.ToLower() == ".jpg" || extension.ToLower() == ".jpeg" || extension.ToLower() == ".png" || extension.ToLower() == ".gif")
                {
                    // Guardar la imagen en el servidor
                    string filename = Guid.NewGuid().ToString() + extension;
                    string filePath = Server.MapPath("~/Uploads/") + filename;
                    fileUploadFotoGrupo.SaveAs(Server.MapPath("~/Uploads/") + filename);
                    // Mostrar la imagen en la página
                    imgFotoGrupo.ImageUrl = "~/Uploads/" + filename;
                    imgFotoGrupo.Visible = true;
                    // Guardamos la referencia en una variable de sesión llamada foto
                    FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                    BinaryReader br = new BinaryReader(fs);
                    Session["foto"] = br.ReadBytes((int)fs.Length);
                    fs.Close();
                }
                else
                {
                    // Mostrar un mensaje de error si el archivo no es una imagen
                    Response.Write("Por favor, selecciona un archivo de imagen válido.");
                }
            }
            else
            {
                // Mostrar un mensaje de error si no se seleccionó ningún archivo
                Response.Write("Por favor, selecciona un archivo de imagen.");
            }
        }

        protected void btnRegresar_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }

        protected void lbBuscarIntegrante_Click(object sender, EventArgs e)
        {
            string script = "window.onload = function() { showModalForm() };";
            ScriptManager.RegisterStartupScript(this, GetType(), "", script, true);
        }

        protected void gvIntegrantes_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvIntegrantes.PageIndex = e.NewPageIndex;
            gvIntegrantes.DataBind();
        }

        protected void gvMiembrosPUCP_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvMiembrosPUCP.PageIndex = e.NewPageIndex;
            gvMiembrosPUCP.DataBind();
        }
    }
}