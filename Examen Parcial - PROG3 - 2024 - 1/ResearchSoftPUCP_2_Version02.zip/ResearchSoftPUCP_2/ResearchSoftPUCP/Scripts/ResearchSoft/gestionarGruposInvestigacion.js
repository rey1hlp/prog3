﻿function showModalForm() {
    var modalForm = new bootstrap.Modal(document.getElementById('form-modal'));
    modalForm.toggle();
}